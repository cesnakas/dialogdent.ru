		jQuery.noConflict();

		/* base url */
		var base_url = "http://dialogdent.ru";
		var WPSC_URL = "http://dialogdent.ru/wp-content/plugins/wp-e-commerce";
		var WPSC_IMAGE_URL = "http://dialogdent.ru/wp-content/uploads/wpsc/product_images/";
		var WPSC_DIR_NAME = "wp-e-commerce";
		var WPSC_CORE_IMAGES_URL = "http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/images";

		/* LightBox Configuration start*/
		var fileLoadingImage = "http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/images/loading.gif";
		var fileBottomNavCloseImage = "http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/images/closelabel.gif";
		var fileThickboxLoadingImage = "http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/images/loadingAnimation.gif";
		var resizeSpeed = 9;  // controls the speed of the image resizing (1=slowest and 10=fastest)
		var borderSize = 10;  //if you adjust the padding in the CSS, you will need to update this variable
