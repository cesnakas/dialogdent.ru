<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="ru-RU">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="ru-RU">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Войти &lsaquo; ДИАЛОГ &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/wp-e-commerce.js?ver=3.8.12.1.55f8cfa0d7'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpsc_ajax = {"ajaxurl":"\/wp-admin\/admin-ajax.php","spinner":"http:\/\/dialogdent.ru\/wp-admin\/images\/wpspin_light.gif","no_quotes":"It appears that there are no shipping quotes for the shipping information provided.  Please check the information and try again."};
/* ]]> */
</script>
<script type='text/javascript' src='http://dialogdent.ru/index.php?wpsc_user_dynamic_js=true&#038;ver=3.8.12.1.55f8cfa0d7'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-admin/js/jquery.livequery.js?ver=1.0.3'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/user.js?ver=3.8.12.155f8cfa0d7'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/thickbox.js?ver=Instinct_e-commerce'></script>
<link rel='stylesheet' id='wpsc-thickbox-css'  href='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/thickbox.css?ver=3.8.12.1.55f8cfa0d7' type='text/css' media='all' />
<link rel='stylesheet' id='wpsc-theme-css-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/wpsc-default.css?ver=3.8.12.1.55f8cfa0d7' type='text/css' media='all' />
<style id='wpsc-theme-css-inline-css' type='text/css'>

		/*
		* Default View Styling
		*/
		div.default_product_display div.textcol{
			margin-left: 218px !important;
			min-height: 208px;
			_height: 208px;
		}

		div.default_product_display  div.textcol div.imagecol{
			position:absolute;
			top:0px;
			left: 0px;
			margin-left: -218px !important;
		}

		div.default_product_display  div.textcol div.imagecol a img {
			width: 208px;
			height: 208px;
		}

		.wpsc_category_grid_item  {
			display:block;
			float:left;
			width: 208px;
			height: 208px;
		}
		.wpsc_category_grid_item  span{
			position:relative;
			top:22.888888888889px;
		}
		div.default_product_display div.item_no_image a  {
			width: 206px;
		}

		div.default_product_display .imagecol img.no-image, #content div.default_product_display .imagecol img.no-image {
			width: 208px;
			height: 208px;
        }

		
		/*
		* Single View Styling
		*/

		div.single_product_display div.item_no_image  {
			width: 206px;
			height: 206px;
		}
		div.single_product_display div.item_no_image a  {
			width: 206px;
		}

		div.single_product_display div.textcol{
			margin-left: 218px !important;
			min-height: 208px;
			_height: 208px;
		}


		div.single_product_display  div.textcol div.imagecol{
			position:absolute;

			margin-left: -218px !important;
		}

		div.single_product_display  div.textcol div.imagecol a img {
			width: 208px;
			height: 208px;
		}

	div#categorydisplay{
		display: block;
	}

	div#branddisplay{
		display: none;
	}

</style>
<link rel='stylesheet' id='wpsc-theme-css-compatibility-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/compatibility.css?ver=3.8.12.1.55f8cfa0d7' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://dialogdent.ru/wp-includes/css/dashicons.min.css?ver=5.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='http://dialogdent.ru/wp-includes/css/buttons.min.css?ver=5.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='http://dialogdent.ru/wp-admin/css/forms.min.css?ver=5.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='http://dialogdent.ru/wp-admin/css/l10n.min.css?ver=5.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='http://dialogdent.ru/wp-admin/css/login.min.css?ver=5.0.9' type='text/css' media='all' />
				<style type="text/css">					#login h1 a {						background-image: url("http://dialogdent.ru/wp-content/uploads/2014/04/logo1.png");						margin: 0 0 0 8px;						width: 329px;
						height: 68px;
						background-size: 329px 68px;
					}				</style>					<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-ru-ru">
		<div id="login">
		<h1><a href="http://dialogdent.ru" title="ДИАЛОГ" tabindex="-1">ДИАЛОГ</a></h1>
	
<form name="loginform" id="loginform" action="http://dialogdent.ru/wp-login.php" method="post">
	<p>
		<label for="user_login">Имя пользователя или e-mail<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Пароль<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Запомнить меня</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Войти" />
		<input type="hidden" name="redirect_to" value="http://dialogdent.ru/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="http://dialogdent.ru/wp-login.php?action=lostpassword">Забыли пароль?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://dialogdent.ru/">&larr; Назад к сайту &laquo;ДИАЛОГ&raquo;</a></p>
		
	</div>

	
		<div class="clear"></div>
	</body>
	</html>
	