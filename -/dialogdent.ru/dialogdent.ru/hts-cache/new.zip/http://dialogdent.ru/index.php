<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="ru-RU">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="ru-RU">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="ru-RU">
<!--<![endif]-->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>ДИАЛОГ | дентал депо</title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,700,400&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
        <script src="http://dialogdent.ru/wp-content/themes/twentythirteen/js.js" type="text/javascript"></script>
        <script src="http://dialogdent.ru/wp-content/themes/twentythirteen/js/bootstrap.min.js"></script>
	<link rel="pingback" href="http://dialogdent.ru/xmlrpc.php">
	<!--[if lt IE 9]>
	<script src="http://dialogdent.ru/wp-content/themes/twentythirteen/js/html5.js"></script>
	<![endif]-->
    <!--[if gte IE 9]>
    <style type="text/css">
        .gradient {
            filter: none;
        }
    </style>
    <![endif]-->

    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="ДИАЛОГ &raquo; Лента" href="http://dialogdent.ru/feed/" />
<link rel="alternate" type="application/rss+xml" title="ДИАЛОГ &raquo; Лента комментариев" href="http://dialogdent.ru/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/dialogdent.ru\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.0.9"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wpsc-thickbox-css'  href='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/thickbox.css?ver=3.8.12.1.55f8cfa0d7' type='text/css' media='all' />
<link rel='stylesheet' id='wpsc-theme-css-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/wpsc-default.css?ver=3.8.12.1.55f8cfa0d7' type='text/css' media='all' />
<style id='wpsc-theme-css-inline-css' type='text/css'>

		/*
		* Default View Styling
		*/
		div.default_product_display div.textcol{
			margin-left: 218px !important;
			min-height: 208px;
			_height: 208px;
		}

		div.default_product_display  div.textcol div.imagecol{
			position:absolute;
			top:0px;
			left: 0px;
			margin-left: -218px !important;
		}

		div.default_product_display  div.textcol div.imagecol a img {
			width: 208px;
			height: 208px;
		}

		.wpsc_category_grid_item  {
			display:block;
			float:left;
			width: 208px;
			height: 208px;
		}
		.wpsc_category_grid_item  span{
			position:relative;
			top:22.888888888889px;
		}
		div.default_product_display div.item_no_image a  {
			width: 206px;
		}

		div.default_product_display .imagecol img.no-image, #content div.default_product_display .imagecol img.no-image {
			width: 208px;
			height: 208px;
        }

		
		/*
		* Single View Styling
		*/

		div.single_product_display div.item_no_image  {
			width: 206px;
			height: 206px;
		}
		div.single_product_display div.item_no_image a  {
			width: 206px;
		}

		div.single_product_display div.textcol{
			margin-left: 218px !important;
			min-height: 208px;
			_height: 208px;
		}


		div.single_product_display  div.textcol div.imagecol{
			position:absolute;

			margin-left: -218px !important;
		}

		div.single_product_display  div.textcol div.imagecol a img {
			width: 208px;
			height: 208px;
		}

	div#categorydisplay{
		display: block;
	}

	div#branddisplay{
		display: none;
	}

</style>
<link rel='stylesheet' id='wpsc-theme-css-compatibility-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/compatibility.css?ver=3.8.12.1.55f8cfa0d7' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='http://dialogdent.ru/wp-includes/css/dist/block-library/style.min.css?ver=5.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='style-name-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/style.css?ver=5.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-fonts-css'  href='//fonts.googleapis.com/css?family=Source+Sans+Pro%3A300%2C400%2C700%2C300italic%2C400italic%2C700italic%7CBitter%3A400%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/fonts/genericons.css?ver=2.09' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-style-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/style.css?ver=2013-07-18' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentythirteen-ie-css'  href='http://dialogdent.ru/wp-content/themes/twentythirteen/css/ie.css?ver=2013-07-18' type='text/css' media='all' />
<![endif]-->
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/wp-e-commerce.js?ver=3.8.12.1.55f8cfa0d7'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpsc_ajax = {"ajaxurl":"\/wp-admin\/admin-ajax.php","spinner":"http:\/\/dialogdent.ru\/wp-admin\/images\/wpspin_light.gif","no_quotes":"It appears that there are no shipping quotes for the shipping information provided.  Please check the information and try again."};
/* ]]> */
</script>
<script type='text/javascript' src='http://dialogdent.ru/index.php?wpsc_user_dynamic_js=true&#038;ver=3.8.12.1.55f8cfa0d7'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-admin/js/jquery.livequery.js?ver=1.0.3'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/user.js?ver=3.8.12.155f8cfa0d7'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/wp-e-commerce/wpsc-core/js/thickbox.js?ver=Instinct_e-commerce'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/product-price/js/wpp_ajax.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/themes/twentythirteen/js/viewportchecker.js?ver=5.0.9'></script>
<link rel='https://api.w.org/' href='http://dialogdent.ru/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://dialogdent.ru/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://dialogdent.ru/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.0.9" />
<link rel='alternate' type='application/rss+xml' title='ДИАЛОГ Product List RSS' href='http://dialogdent.ru/?wpsc_action=rss'/>
<!-- Facebook Pixel Code -->
<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>
<!-- End Facebook Pixel Code -->
<script type='text/javascript'>
  fbq('init', '924292447770627', [], {"agent":"wordpress-5.0.9-1.7.21"});
</script><script type='text/javascript'>
  fbq('track', 'PageView', []);
</script>
<!-- Facebook Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=924292447770627&ev=PageView&noscript=1" />
</noscript>
<!-- End Facebook Pixel Code -->
	<style type="text/css" id="twentythirteen-header-css">
			.site-header {
			background: url(http://dialogdent.ru/wp-content/themes/twentythirteen/images/headers/circle.png) no-repeat scroll top;
			background-size: 1600px auto;
		}
		</style>
	</head>

<body class="home blog single-author sidebar">
    <!--<h1>local host</h1>-->
        <div class="header-container">
        <div class="header">
            <div class="logo pull-left" onclick="window.location='/';"></div>
            <div class="search pull-right">
                <form action="/" method="get">
	<input value="" name="s" id="s" class="form-control input-sm" type="text" placeholder="поиск в каталоге">
</form>            </div>
        </div>
    </div><br />
    <div class="menu-container">
        <div class="menu-menu-container"><ul id="menu-menu" class="menu"><li id="menu-item-9" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9"><a href="http://dialogdent.ru/o-kompanii/">О компании</a></li>
<li id="menu-item-30" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-30"><a href="http://dialogdent.ru/news/">Новости</a></li>
<li id="menu-item-101" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-101"><a href="http://dialogdent.ru/produkciya/">Продукция</a></li>
<li id="menu-item-1056" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1056"><a href="http://dialogdent.ru/akcii/">Акции</a></li>
<li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-57"><a href="http://dialogdent.ru/kontakty/">Контакты</a></li>
<li id="menu-item-1322" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1322"><a href="http://dialogdent.ru/obuchenie/">Обучение</a></li>
<li id="menu-item-1416" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1416"><a href="http://dialogdent.ru/wp-login.php">Войти</a></li>
<li id="menu-item-1417" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1417"><a href="http://dialogdent.ru/wp-login.php?action=register">Регистрация</a></li>
</ul></div>	</div>

    <div class="breadcrumb-container">
        <ol class="breadcrumb">
                    </ol>
    </div>
    
    <div class="content-container">
        <div class="content">
    <!-- -->
    
<!-- meta slider -->
<div style="width: 100%;" class="metaslider metaslider-flex metaslider-44 ml-slider">
    <style type="text/css">
        @import url('http://dialogdent.ru/wp-content/plugins/ml-slider/assets/metaslider/public.css?ver=2.4.1');
        @import url('http://dialogdent.ru/wp-content/plugins/ml-slider/assets/sliders/flexslider/flexslider.css?ver=2.4.1');
        #metaslider_44.flexslider li {margin-right: 5px;}
    </style>
    <div id="metaslider_container_44">
        <div id="metaslider_44" class="flexslider">
            <ul class="slides">
                <li style="display: none;"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-materials/diski-pritidenta-iz-dioksida-cirkoniya-98-5-mm-germaniya/" target="_self"><img src="http://dialogdent.ru/wp-content/uploads/2017/05/slaid-p.jpg" height="300" width="1000" class="slider-44 slide-1854" /></a></li>
                <li style="display: none;"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-kit/" target="_self"><img src="http://dialogdent.ru/wp-content/uploads/2017/05/slaid-s.jpg" height="300" width="1000" class="slider-44 slide-1855" /></a></li>
                <li style="display: none;"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-3shape/laboratornyj-skaner-e1/" target="_self"><img src="http://dialogdent.ru/wp-content/uploads/2017/05/slaid-3s.jpg" height="300" width="1000" class="slider-44 slide-1858" /></a></li>
                <li style="display: none;"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-stl/skaner-laboratornyj-egs-dscan-3-italiya/" target="_self"><img src="http://dialogdent.ru/wp-content/uploads/2017/05/slaid-egs.jpg" height="300" width="1000" class="slider-44 slide-1859" /></a></li>
            </ul>
        </div>
    </div>
    <script type="text/javascript">
        var metaslider_44 = function($) {
            $('#metaslider_44').flexslider({ 
                slideshowSpeed:6000,
                animation:'slide',
                controlNav:true,
                directionNav:true,
                pauseOnHover:true,
                direction:'horizontal',
                reverse:false,
                animationSpeed:600,
                prevText:"<",
                nextText:">",
                easing:"linear",
                slideshow:true,
                itemWidth:1000,
                minItems:1,
                itemMargin:5,
                useCSS:false
            });
        };
        var timer_metaslider_44 = function() {
            var slider = !window.jQuery ? window.setTimeout(timer_metaslider_44, 100) : !jQuery.isReady ? window.setTimeout(timer_metaslider_44, 100) : metaslider_44(window.jQuery);
        };
        timer_metaslider_44();
    </script>
</div>
<!--// meta slider-->    <!-- -->

    <div class="sidebar-left pull-left">
        <!-- Button trigger modal -->






            <div class="news-fresh bs-sidebar hidden-print" role="complementary">

 <aside id="text-2" class="widget widget_text"><h3 class="widget-title">Меню</h3>			<div class="textwidget">Каталог товаров:</div>
		</aside><aside id="nav_menu-2" class="widget widget_nav_menu"><h3 class="widget-title">Произвол</h3><div class="menu-produkciya-container"><ul id="menu-produkciya" class="menu"><li id="menu-item-1780" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-has-children menu-item-1780"><a href="http://dialogdent.ru/produkciya/cadcam/">CAD/CAM</a>
<ul class="sub-menu">
	<li id="menu-item-1781" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1781"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-kit/">Комплекты CAD/CAM</a></li>
	<li id="menu-item-1782" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1782"><a href="http://dialogdent.ru/produkciya/cadcam/cad_cam_sirona/">SIRONA</a></li>
	<li id="menu-item-1797" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1797"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-3shape/">3Shape</a></li>
	<li id="menu-item-1799" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1799"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-stl/">Открытые системы (STL)</a></li>
	<li id="menu-item-1798" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1798"><a href="http://dialogdent.ru/produkciya/cadcam/cadcam-materials/">Расходные материалы</a></li>
</ul>
</li>
<li id="menu-item-1783" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1783"><a href="http://dialogdent.ru/produkciya/ystanovki/">Установки</a></li>
<li id="menu-item-1784" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1784"><a href="http://dialogdent.ru/produkciya/rentgenovskie_sistems/">Рентгеновские системы</a></li>
<li id="menu-item-1785" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1785"><a href="http://dialogdent.ru/produkciya/pribori_i_instrumenti/">Приборы и инстументы</a></li>
<li id="menu-item-1786" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1786"><a href="http://dialogdent.ru/produkciya/sterelizacia/">Стерилизация</a></li>
<li id="menu-item-1787" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1787"><a href="http://dialogdent.ru/produkciya/opiracionnie_mkroskopi/">Оптика и микроскопы</a></li>
<li id="menu-item-1788" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1788"><a href="http://dialogdent.ru/produkciya/ergonomichnie_stulia/">Эргономичные стулья</a></li>
<li id="menu-item-1789" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1789"><a href="http://dialogdent.ru/produkciya/mebel/">Мебель</a></li>
<li id="menu-item-1790" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1790"><a href="http://dialogdent.ru/produkciya/xirurgia/">Хирургия</a></li>
<li id="menu-item-1791" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1791"><a href="http://dialogdent.ru/produkciya/ortopedia/">Ортопедия</a></li>
<li id="menu-item-1792" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1792"><a href="http://dialogdent.ru/produkciya/endodontia/">Эндодонтия</a></li>
<li id="menu-item-1793" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1793"><a href="http://dialogdent.ru/produkciya/terapia/">Терапия и эстетика</a></li>
<li id="menu-item-1794" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1794"><a href="http://dialogdent.ru/produkciya/otbelivanie/">Отбеливание</a></li>
<li id="menu-item-1795" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1795"><a href="http://dialogdent.ru/produkciya/zybotexnicheskaa_laboratoria/">Зуботехническая лаборатория</a></li>
<li id="menu-item-1796" class="menu-item menu-item-type-taxonomy menu-item-object-wpsc_product_category menu-item-1796"><a href="http://dialogdent.ru/produkciya/gigiena/">Гигиена</a></li>
</ul></div></aside></div>

            </div>

	<div class="area-right pull-left">
        <div class="catalog-fresh">
                <!-- start -->
                                    		                    <!-- end -->
        </div>
	</div>
	<div class="clearfix"></div>



        <div id="sys-panel">
            <div class="row">
                <div class="cart-block">
                    <!--<span class="glyphicon glyphicon-shopping-cart"></span>-->
                                                <aside id="wppp_widget-3" class="widget widget_wppp_widget"><div class="get-prod-wrap"><div class="wpp-msg"></div><div class="wpp-text">Нет товаров для уточнения</div></div></aside>                                        </div>
                    <!--<a id="show-cart" href="#" data-toggle="modal" data-target="#myModal"></span>Корзина</a>-->
                <div class="question">
                    <a id="show_qst" href="#"><span class="glyphicon glyphicon-question-sign"></span>Задать вопрос</a>
                </div>
            </div>
            <div id="qst" class="qst">
                <script type="text/javascript">
                    var RecaptchaOptions = {
                        theme : 'custom',
                        custom_theme_widget: 'recaptcha_widget'
                    };
                </script>
                <form id="ask">
                    <div class="form-group">
                        <input type="text" class="form-control" name="qname" placeholder="Имя" required="required">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" name="qmail" placeholder="E-mail" required="required">
                    </div>
                    <div class="form-group">
                        <textarea name="qtext" class="form-control"></textarea>
                    </div>
                    <div id="recaptcha_widget" style="display:none">

                        <div id="recaptcha_image" class="form-group"></div>
                        <div class="recaptcha_only_if_incorrect_sol" style="color:red">Incorrect please try again</div>

                        <!--<span class="recaptcha_only_if_image">Enter the words above:</span>-->
                        <!--<span class="recaptcha_only_if_audio">Enter the numbers you hear:</span>-->
                        <div class="form-group">
                            <input type="text" id="recaptcha_response_field" class="form-control" name="recaptcha_response_field" placeholder="Текст с картинки выше" />
                        </div>
                        <!--<div class="recaptcha_only_if_audio"><a href="javascript:Recaptcha.switch_type('image')">Помощь</a></div>-->
                        <!--<div><a href="javascript:Recaptcha.showhelp()">Help</a></div>-->

                    </div>

                    <script type="text/javascript" src="http://www.google.com/recaptcha/api/challenge?k=6LfCevMSAAAAANRES7OlGQsgd0H92sCWTKb2Raa2">
                    </script>
                    <noscript>
                        <iframe src="http://www.google.com/recaptcha/api/noscript?k=6LfCevMSAAAAANRES7OlGQsgd0H92sCWTKb2Raa2" height="300" width="500" frameborder="0"></iframe><br>
                        <textarea name="recaptcha_challenge_field" rows="3" cols="40"></textarea>
                        <input type="hidden" name="recaptcha_response_field" value="manual_challenge">
                    </noscript>
                                        <input type="hidden" name="qtheme" value="ОТБЕЛИВАНИЕ ЗУБОВ С ПРИМЕНЕНИЕМ ПРОФЕССИОНАЛЬНЫХ <br>СИСТЕМ В КЛИНИЧЕСКИХ И ДОМАШНИХ УСЛОВИЯХ">
                    <input type="hidden" name="action" value="send_question">
                    <div class="row">
                        <div class="col-xs-6">
                            <div><a href="javascript:Recaptcha.reload()" class="btn btn-default">Обновить</a></div>
                            <!--<div class="recaptcha_only_if_image"><a href="javascript:Recaptcha.switch_type('audio')">Прослушать</a></div>-->
                        </div>
                        <div class="col-xs-6"><input type="submit" class="btn btn-default" value="отправить"></div>
                    </div>

                </form>
            </div>
        </div>


    </div><!-- content -->
</div><!-- content-container -->

<footer id="colophon" class="site-footer" role="contentinfo">
    </footer><!-- #colophon footer -->

<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/imagesloaded.min.js?ver=3.2.0'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/masonry.min.js?ver=3.3.2'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/jquery/jquery.masonry.min.js?ver=3.1.2b'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/themes/twentythirteen/js/functions.js?ver=2013-07-18'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-includes/js/wp-embed.min.js?ver=5.0.9'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/ml-slider/assets/sliders/flexslider/jquery.flexslider-min.js?ver=2.4.1'></script>
<script type='text/javascript' src='http://dialogdent.ru/wp-content/plugins/ml-slider/assets/easing/jQuery.easing.min.js?ver=2.4.1'></script>
<script src="http://dialogdent.ru/wp-content/themes/twentythirteen/js/bootstrap.min.js"></script>
					
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <form method="post">
    <div class="modal-content">

        <div id="" class="nsc">
            <h3 class="text-center">Подписка на новости</h3>
                <div class="form-group">
                    <input type="text" class="form-control" name="nname" placeholder="Имя" required="required">
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" name="nmail" placeholder="E-mail">
                </div>
                <input type="hidden" name="qtheme" value="ОТБЕЛИВАНИЕ ЗУБОВ С ПРИМЕНЕНИЕМ ПРОФЕССИОНАЛЬНЫХ <br>СИСТЕМ В КЛИНИЧЕСКИХ И ДОМАШНИХ УСЛОВИЯХ"><br>
                <!--<p class="text-center"><input type="submit" name="" value="отправить"></p>-->

        </div>

	          <div class="modal-footer">
        <button type="submit" class="btn btn-default">Отправить</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
      </div>
    </div><!-- /.modal-content -->
      </form>
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

</body>
</html>